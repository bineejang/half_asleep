package com.example.half_asleep;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MainActivity extends AppCompatActivity {
    final String TAG = this.getClass().getSimpleName();

    LinearLayout center_ly;
    BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init(); //객체 정의
        SettingListener(); //리스너 등록

        //맨 처음 시작할 탭 설정
        bottomNavigationView.setSelectedItemId(R.id.tab_home);



    }

    private void init() {
        center_ly = findViewById(R.id.change_LinearLayout);  //fragment가 들어가는 리니어레이아웃
        bottomNavigationView = findViewById(R.id.menu_bottom_navigation);
    }

    private void SettingListener() {
        //선택 리스너 등록
        bottomNavigationView.setOnNavigationItemSelectedListener(new TabSelectedListener());
    }

    class TabSelectedListener implements BottomNavigationView.OnNavigationItemSelectedListener{
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
            TextView selected = findViewById(R.id.select_frag);  //타이틀바 하단의 선택창

            switch (menuItem.getItemId()) {
                case R.id.tab_home: {
                    selected.setText("G a l l e r y");
                    getSupportFragmentManager().beginTransaction()
                            .replace(R.id.change_LinearLayout, new HomeFragment())
                            .commit();
                    return true;
                }
                case R.id.tab_commu: {
                    selected.setText("C o m m u n i t y");
                    getSupportFragmentManager().beginTransaction()
                            .replace(R.id.change_LinearLayout, new CommuFragment())
                            .commit();
                    return true;
                }
                case R.id.tab_friend: {
                    selected.setText("F r i e n d s");
                    getSupportFragmentManager().beginTransaction()
                            .replace(R.id.change_LinearLayout, new FriendFragment())
                            .commit();
                    return true;
                }
                case R.id.tab_settings: {
                    selected.setText("s e t t i n g s");
                    getSupportFragmentManager().beginTransaction()
                            .replace(R.id.change_LinearLayout, new SettingsFragment())
                            .commit();
                    return true;
                }
            }

            return false;
        }

    }
}